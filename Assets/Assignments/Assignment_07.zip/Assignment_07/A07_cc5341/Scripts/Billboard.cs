﻿using System.Collections;
using UnityEngine;

public class Billboard : MonoBehaviour {

	void Update () {
        transform.LookAt(Camera.main.transform);
	}
}
